<?php

/**
 * index.php
 *
 * Copyright (c) 1999-2011 The SquirrelMail Project Team
 * Licensed under the GNU GPL. For full terms see the file COPYING.
 *
 * This file simply takes any attempt to view source files and sends those
 * people to the login screen. At this point no attempt is made to see if
 * the person is logged or not.
 *
 * $Id$
 */

header("Location:../index.php");

/* pretty impressive huh? */

